import sys

nit = {
    "Redvital": 1061278012
}

print(nit["Redvital"])