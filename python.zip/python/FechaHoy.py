import datetime

#FECHA ACTUAL
ahora = datetime.datetime.utcnow()
print(ahora)

